# Task 1 — Dual LED PWM

## Objective
Control two LEDs independently with smooth fading and different PWM frequencies.

## Wiring (ESP32 DevKit V1)
- GPIO 18 -> separate 220 ohm resistor -> LED 1 anode (+); LED 1 cathode (-) -> GND.
- GPIO 19 -> separate 220 ohm resistor -> LED 2 anode (+); LED 2 cathode (-) -> GND.
- Use one current-limiting resistor for each LED.

## PWM settings
| LED | GPIO | LEDC channel | Frequency | Resolution |
|---|---:|---:|---:|---:|
| LED 1 | 18 | 0 | 1000 Hz (1 kHz) | 8 bit |
| LED 2 | 19 | 8 | 5000 Hz (5 kHz) | 8 bit |

An 8-bit duty value ranges from 0 to 255. The program gradually increases the duty from 0 to 255 and decreases it back to 0. A higher duty cycle makes an LED appear brighter. PWM frequency is the number of switching cycles per second; the duty cycle controls the fraction of each cycle that is ON.

## ESP32 LEDC note
This configuration targets the original ESP32 DevKit V1. Its LEDC channels 0–7 and 8–15 are in separate channel groups, so channel 0 and channel 8 are selected for separate frequency settings. Other ESP32 variants may have different LEDC resources; check the selected chip before using this channel arrangement.

The code supports Arduino-ESP32 core 2.x and 3.x APIs.

## Wokwi
Open this folder as an ESP32 PlatformIO project in Wokwi, run the simulation, and verify that both LEDs fade. Save your own circuit and running-simulation screenshots in `screenshots/`.

Wokwi project URL: **Add your own saved Wokwi share link here.**

## Hardware
Build the same circuit on the physical ESP32 kit. Disconnect power before changing wiring. Verify fading 